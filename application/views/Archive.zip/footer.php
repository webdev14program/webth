<!-- <footer class="site-footer bg-secondary">
  <h3 class="text-center text-white">Copyright 2019 SMK TUNAS HARAPAN All rights reserved.</h3>
</footer> -->

<div class="card bg-secondary mt-4">
  <div class="card-body">
    <h5 class="text-center text-white text-footer">Copyright 2019 SMK TUNAS HARAPAN All rights reserved.</h5>

  </div>
</div>
<!-- END footer -->

<!-- loader -->
<div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
    <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
    <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#f4b214" />
  </svg></div>

<script src="<?= base_url() ?>assets/js/jquery-3.2.1.min.js"></script>
<script src="<?= base_url() ?>assets/js/jquery-migrate-3.0.0.js"></script>
<script src="<?= base_url() ?>assets/js/popper.min.js"></script>
<script src="<?= base_url() ?>assets/js/bootstrap.min.js"></script>
<script src="<?= base_url() ?>assets/js/owl.carousel.min.js"></script>
<script src="<?= base_url() ?>assets/js/jquery.waypoints.min.js"></script>
<script src="<?= base_url() ?>assets/js/jquery.stellar.min.js"></script>
<script src="<?= base_url() ?>assets/js/jquery.animateNumber.min.js"></script>

<script src="<?= base_url() ?>assets/js/jquery.magnific-popup.min.js"></script>

<script src="<?= base_url() ?>assets/js/main.js"></script>
</body>

</html>