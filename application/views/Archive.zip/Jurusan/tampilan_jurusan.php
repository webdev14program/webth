<!-- END header -->

<section class="site-hero site-sm-hero overlay bg-primary" data-stellar-background-ratio="0.5">
    <div class="container">
        <div class="row align-items-center justify-content-center site-hero-sm-inner">
            <div class="col-md text-center">

                <div class="mb-5 element-animate">
                    <h1 class="mb-2 font-weight-bold text-uppercase"><?= $jurusan ?></h1>
                </div>

            </div>
        </div>
    </div>
</section>
<!-- END section -->

<?php $this->load->view($content); ?>