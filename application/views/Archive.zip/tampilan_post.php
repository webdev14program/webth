<!-- END header -->

<section class="site-hero site-sm-hero overlay bg-primary" data-stellar-background-ratio="0.5">
    <div class="container">
        <div class="row align-items-center justify-content-center site-hero-sm-inner">
            <div class="col-md-7 text-center">

                <div class="mb-5 element-animate">
                    <h1 class="mb-2 text-uppercase font-weight-bold">Post</h1>
                </div>

            </div>
        </div>
    </div>
</section>
<!-- END section -->

<section class="site-section element-animate">
    <div class="container">
        <?php foreach ($post as $row) : ?>
            <div class="row mt-4 mb-4">
                <div class="col-md">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <h5 class="text-center">
                                        <img src="<?= base_url() ?>assets/upload/<?= $row['gambar'] ?>" style="width: 250px;height: 200px;">
                                    </h5>
                                </div>
                                <div class="col-md-9">
                                    <h5 class="text-center text-uppercase font-weight-bold"><?= $row['nama_kegiatan'] ?></h5>
                                    <br>
                                    <h5 class="text-center text-uppercase font-weight-bold"><?= $row['detail_kegiatan'] ?></h5>
                                    <br>
                                    <h5 class=" text-uppercase font-weight-bold" disabled><?= $row['date'] ?></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
</section>
<!-- END section -->

<div id="map"></div>